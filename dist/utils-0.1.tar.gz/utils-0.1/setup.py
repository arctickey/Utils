from setuptools import setup

setup(name="utils", version="0.1", packages=["utils"])
