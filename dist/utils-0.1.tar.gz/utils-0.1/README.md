# Utils
Utils package for this repository https://github.com/okcze/praca_inzynierska_zms
